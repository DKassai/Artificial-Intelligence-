import sys
f = open(f"{sys.argv[1]}_output.txt",'r')
lines = f.readlines()
f.close()
indices = [i+1 for i, x in enumerate(lines) if x == "Testing...\n"]
f = open(f"{sys.argv[1]}_output.txt",'w')
f.write("faces\n\nTraining Set Size\tCorrectness\n")
pct = 10
for i in indices:
	if i == indices[int(len(indices)/2)]:
		f.write("\n\ndigits\n\nTraining Set Size\tCorrectness\n")
		pct = 10
	f.write(f"{pct}%\t\t\t" +lines[i][lines[i].index('(')+1:-6]+'%\n')
	pct+=10
