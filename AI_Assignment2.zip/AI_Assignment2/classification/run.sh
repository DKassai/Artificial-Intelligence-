clear
echo --------------------
echo Perceptron - faces
echo --------------------
time python dataClassifier.py -c perceptron -d faces -t 451

echo ""
echo ""
echo --------------------
echo Perceptron - digits
echo --------------------
time python dataClassifier.py -c perceptron -d digits -t 5000

echo ""
echo ""
echo --------------------
echo Naive Bayes - faces
echo --------------------
time python dataClassifier.py -c nb -d faces -t 450

echo ""
echo ""
echo --------------------
echo Naive Bayes - digits
echo --------------------
time python dataClassifier.py -c nb -d digits -t 5000

echo ""
echo ""
echo --------------------
echo MIRA - faces
echo --------------------
time python dataClassifier.py -c mira -d faces -t 450

echo ""
echo ""
echo --------------------
echo MIRA - digits
echo --------------------
time python dataClassifier.py -c mira -d digits -t 5000