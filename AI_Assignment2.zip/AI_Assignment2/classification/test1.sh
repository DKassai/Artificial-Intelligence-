for (( i=45; i<451; i+=45 ))
do
    echo $i
done


for j in {500..5000..500}
do
    python dataClassifier.py -c naiveBayes -d digits -t $j
done



