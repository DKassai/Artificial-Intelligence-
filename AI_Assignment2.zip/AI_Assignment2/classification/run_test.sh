./test.sh nb
./test.sh perceptron
./test.sh mira
