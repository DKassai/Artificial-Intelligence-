f1 = open('output3.txt', 'r')
f2 = open('output4.txt', 'r')

s1 = f1.read()
s2 = f2.read()

for i in range(len(s1)):
    if s1[i] != s2[i]:
        print "FAIL", i
        print s1[i:i+50]
        print s2[i:i+50]
        exit()

print "SUCCESS"
