echo "" > $1_output.txt
j=0
for (( i=45; i<451; i+=45 ))
do
    echo $1 $j, $i
    j+=1
    python dataClassifier.py -c $1 -d faces -t $i >> $1_output.txt
done

j=0
for (( i=500; i<5001; i+=500 ))
do
    echo $1 $j, $i
    j+=1
    python dataClassifier.py -c $1 -d digits -t $i >> $1_output.txt
done

python3 clean.py $1
