# naiveBayes.py
# -------------
# Licensing Information: Please do not distribute or publish solutions to this
# project. You are free to use and extend these projects for educational
# purposes. The Pacman AI projects were developed at UC Berkeley, primarily by
# John DeNero (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# For more info, see http://inst.eecs.berkeley.edu/~cs188/sp09/pacman.html

import util
import classificationMethod
import math

class NaiveBayesClassifier(classificationMethod.ClassificationMethod):
  """
  See the project description for the specifications of the Naive Bayes classifier.
  
  Note that the variable 'datum' in this code refers to a Total_counter of features
  (not to a raw samples.Datum).
  """
  def __init__(self, legalLabels):
    self.legalLabels = legalLabels
    self.type = "naivebayes"
    self.k = 1 # this is the smoothing parameter, ** use it in your train method **
    self.automaticTuning = False # Look at this flag to decide whether to choose k automatically ** use this in your train method **
    
  def setSmoothing(self, k):
    """
    This is used by the main method to change the smoothing parameter before training.
    Do not modify this method.
    """
    self.k = k

  def train(self, trainingData, trainingLabels, validationData, validationLabels):
    """
    Outside shell to call your method. Do not modify this method.
    """   
      
    # might be useful in your code later...
    # this is a list of all features in the training set.
    self.features = list(set([ f for datum in trainingData for f in datum.keys() ]));
    
    if (self.automaticTuning):
        kgrid = [0.001, 0.01, 0.05, 0.1, 0.5, 1, 5, 10, 20, 50]
    else:
        kgrid = [self.k]
        
    self.trainAndTune(trainingData, trainingLabels, validationData, validationLabels, kgrid)
      
  def trainAndTune(self, trainingData, trainingLabels, validationData, validationLabels, tuning_value):
    """
    Trains the classifier by collecting counts over the training data, and
    stores the Laplace smoothed estimates so that they can be used to classify.
    Evaluate each value of k in kgrid to choose the smoothing parameter 
    that gives the best accuracy on the held-out validationData.
    
    trainingData and validationData are lists of feature Counters.  The corresponding
    label lists contain the correct label for each datum.
    
    To get the list of all possible features or labels, use self.features and 
    self.legalLabels.
    """

    "*** YOUR CODE HERE ***"
   
 
    Total_conditional_probability = util.Counter()
    Total_label_probability= util.Counter()
    Total_counter = util.Counter()

    for i in range(len(trainingData)):
      label=trainingLabels[i]
      x_n = trainingData[i]
      Total_label_probability[label]+=1
      j=0

      for data in x_n.items():
        features = data[0]
        values = data[1]
        Total_counter[(features,label)]+=1
        if values>0:
          Total_conditional_probability[(features,label)]+=1


    # print(len(Total_conditional_probability),len(Total_label_probability),len(Total_counter))
    best_count = 0
    labels = util.Counter()
    condition_probability = util.Counter()
    counter = util.Counter()


    for data in Total_conditional_probability.items():
      key = data[0]
      value = data[1]
      condition_probability[key]+= value
    
    for data in Total_counter.items():
      key = data[0]
      value = data[1]
      counter[key]+=value

    for legal_label in self.legalLabels:
      for feature in self.features:
        condition_probability[(feature,legal_label)]+=tuning_value[0]
        counter[(feature,legal_label)]+=2*tuning_value[0]


    for data in Total_label_probability.items():
      key = data[0]
      value = data[1]
      labels[key]+=value

    labels.normalize()
    for x, count in condition_probability.items():
      condition_probability[x] = float(count) / counter[x]

    self.lbls = labels
    self.cond_prob = condition_probability

    # util.raiseNotDefined()
        
  def classify(self, testData):
    """
    Classify the data based on the posterior distribution over labels.
    
    You shouldn't modify this method.
    """
    guesses = []
    self.posteriors = [] # Log posteriors are stored for later data analysis (autograder).
    for datum in testData:
      posterior = self.calculateLogJointProbabilities(datum)
      guesses.append(posterior.argMax())
      self.posteriors.append(posterior)
    return guesses
      
  def calculateLogJointProbabilities(self, datum):
    """
    Returns the log-joint distribution over legal labels and the datum.
    Each log-probability should be stored in the log-joint counter, e.g.    
    logJoint[3] = <Estimate of log( P(Label = 3, datum) )>
    
    To get the list of all possible features or labels, use self.features and 
    self.legalLabels.
    """
    logJoint = util.Counter()
    
    "*** YOUR CODE HERE ***"
    for label in self.legalLabels:
      logJoint[label] = math.log(self.lbls[label])
      for data in datum.items():
        key = data[0]
        if data[1] > 0:
          logJoint[label] += math.log(self.cond_prob[key,label])
        else:
          logJoint[label] += math.log(1 - self.cond_prob[key,label])

#    util.raiseNotDefined()
    return logJoint
  